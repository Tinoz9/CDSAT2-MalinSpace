﻿namespace AstroFormula
{
    public class AstroFormula
    {

        public double StarVelocity(double observedWave, double restWave)
        {
            int SOL = 299792458;
            double changeWave = observedWave - restWave;
            return (SOL * (changeWave / restWave));
        }

        public double StarDistance(double arcs)
        {
            return (1 / arcs);
        }

        public double TemperatureKelvin(double celcius)
        {
            if (celcius <= -273) 
            {
                celcius = 272;
            }
            return celcius + 273.0;
        }

        public double EventHorizon (double mass)
        {
            double GC = 6.674 * Math.Pow(10.0, -11);
            int SOL = 299792458;

            return 2*(GC*mass) / Math.Pow(SOL, 2);
        }
    }
}